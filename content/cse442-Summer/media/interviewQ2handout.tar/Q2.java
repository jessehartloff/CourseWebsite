public class Q2 {

    /***
     * Return the index of toFind in sortedArray. Return -1 if the value is not found. The array has unknown size and
     * only the supports the .at(index) function.
     */
    public static int find(int toFind, ArrayWrapper sortedArray){
        // TODO
        return -1;
    }

}
