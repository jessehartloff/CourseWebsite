package lecture;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Vector;

public class CSVSimpleParser {
	
	public Vector<Vector<String>> parseFile(String fileName) {
		
		Vector<Vector<String>> fileVector = new Vector<Vector<String>>(); // data structure to store file

		try {
			
			// open the file as an input stream
			InputStream inputStream = SubscriberSplit.class.getResourceAsStream(fileName);
			
			// buffer the stream to read lines
			BufferedReader fileIn = new BufferedReader(new InputStreamReader(inputStream));
			
			String currentLine;
			// loop through the file until all lines are read
			while ((currentLine = fileIn.readLine()) != null) {
				
				// use the string split function to break up the string on the commas
				String[] aLine = currentLine.split(",");
				
				// copy the array into a line vector
				Vector<String> vLine = new Vector<String>();
				for (String s:aLine){
					vLine.add(s);
				}
				
				// then add the line vector to the file vector
				fileVector.add(vLine);
			}
			
			fileIn.close();
		} catch (Exception e) {
			
			System.out.println("File Not Found!");
		} 
		
		return fileVector;
	}
}
