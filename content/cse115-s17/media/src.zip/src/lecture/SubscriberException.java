package lecture;

public class SubscriberException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SubscriberException(String s){
		super(s);
	}
	
}
