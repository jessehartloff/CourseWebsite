package lecture;

import java.util.Vector;

public class Student {

	String firstName;
	String lastName;
	String email;
	String studentNumber;

	public Student(){
		
	}
	
	public Student(Vector<String> input) {
		
		setFirstName(input.get(0));
		setLastName(input.get(1));
		setEmail(input.get(2));
		setStudentNumber(input.get(3));
		
	}
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getStudentNumber() {
		return studentNumber;
	}

	public void setStudentNumber(String studentNumber) {
		this.studentNumber = studentNumber;
	}

}
