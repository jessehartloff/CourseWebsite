package lecture;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Vector;

/**
 * @author Alan Hunt
 * 
 *         CSVReader prompts the user for a filename containing CSV data, then
 *         displays it in a formatted manner on the console
 *
 */
public class CSVReader {

	public static void main(String[] args) {

			
		// prompt the user for the input file name
		System.out.println("Enter a file name to read ");
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

		String file;
		try {

			// read in the CSV file name
			file = in.readLine();

			CSVSimpleParser parser = new CSVSimpleParser();
			// DelimitedFileParser parser = new DelimitedFileParser();
			Vector<Vector<String>> fileVector = parser.parseFile(file);

			// for each line in the file, display to the console
			for (Vector<String> line : fileVector) {
				System.out.println(line);
				// printFormattedLine(line);
				// Student s = new Student(line);
			}

		} catch (Exception e) {
			System.out.println("Error reading user input");
			e.printStackTrace();
		}
	}

	/**
	 * @param line
	 * 
	 *            printFormattedLine takes in a vector of strings, and displays
	 *            them to the console aligned at 25 characters. If any data
	 *            field is longer than 25 characters, this will not display
	 *            cleanly
	 */
	public static void printFormattedLine(Vector<String> line) {
		for (String s : line) {

			System.out.print(pad(s, 25));
		}
		System.out.print("\n");
	}

	/**
	 * @param s
	 *            the string to pad
	 * @param size
	 *            the size to pad it to
	 * @return the padded string
	 * 
	 *         pad takes in a string, and a size, and returns a string with the
	 *         same content plus a number of spaces at then end that pads it to
	 *         the input size
	 */
	public static String pad(String s, int size) {
		int padSize = size - s.length();
		for (int i = 0; i < padSize; i++) {
			s = s + " ";
		}
		return s;
	}

}
