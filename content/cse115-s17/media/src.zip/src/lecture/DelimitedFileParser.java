package lecture;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Vector;

public class DelimitedFileParser {

	public Vector<Vector<String>> parseFile(String fileName) {
		
		Vector<Vector<String>> fileVector = new Vector<Vector<String>>();  // data structure to store file

		try {
			
			// open the file 
			String fileDirectory = "src/lecture/";
			FileReader fr = new FileReader(new File (fileDirectory+fileName));
			
			// buffer the reader to read lines
			BufferedReader fileIn = new BufferedReader(fr);
			
			String indexLine;
			
			while ((indexLine = fileIn.readLine()) != null) {		
				fileVector.add(parseLine(indexLine));
			}
			
			fileIn.close();
			
		} catch (Exception e) {
			
			System.out.println("File Not Found!");
		} 
		
		return fileVector;
	}
	
	// convenience case - most common delimiter and escape
	public Vector<String> parseLine(String s){
		return parseLine(s, ',', '\"');
	}
	
	public Vector<String> parseLine(String s, char delimiter, char escape){
		Vector<String> line = new Vector<String>();
		
		int start = 0;
		boolean escaped = false;  // initialize escape state
		
		for (int index = 0; index < s.length(); index++) {
		    if (s.charAt(index) == escape){
		    	escaped = !escaped; // toggle state
		    }
		    
		    // edge case - have we parsed to the end of the string?
		    // if so, add the token
		    boolean atLastChar = (index == s.length() - 1);
		    if(atLastChar) {
		    	
		    		line.add(trimQuotes(s.substring(start)));
		    	
		    }
		    // otherwise, if we hit a delimiter, and we're not escaped, 
		    // add the token, and reset the start of the index
		    else if (s.charAt(index) == delimiter && !escaped) {
		        line.add(trimQuotes(s.substring(start, index)));
		        start = index + 1;
		    }
		}
		return line;
	}
	
	String trimQuotes (String s){
		if (s.contains("\"")){
			return s.substring(1, s.length() - 2);
		}
		return s;
	}
}
