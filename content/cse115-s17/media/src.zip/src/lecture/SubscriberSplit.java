package lecture;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

/**
 * @author Alan Hunt
 * 
 *         SubscriberSplit takes in a file name for a CSV file with subscriber
 *         data, and outputs one CSV file for each state
 *
 */
public class SubscriberSplit {

	public static void main(String[] args) {

		// create the hash table to sort the subscribers by state
		Hashtable<String, Vector<Subscriber>> stateHash = new Hashtable<String, Vector<Subscriber>>();

		// ask the user for the filename to read
		System.out.println("Enter a file name to read ");
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

		String file;
		try {
			file = in.readLine();
			
			// parse the file indicated
			DelimitedFileParser parser = new DelimitedFileParser();
			Vector<Vector<String>> fileVector = parser.parseFile(file);

			// loop through the vector of parsed lines, and for each one create a subscriber record and hash it to a state
			for (Vector<String> line : fileVector) {
				Subscriber s = new Subscriber(line);
				System.out.println(s.getCompany());

				if (stateHash.get(s.getState()) == null) {
					Vector<Subscriber> v = new Vector<Subscriber>();
					v.add(s);
					stateHash.put(s.getState(), v);
				} else {
					stateHash.get(s.getState()).add(s);
				}
			}

			// now, loop through the hash table, writing each state out to a
			// separate file
			Enumeration<String> states = stateHash.keys();

			while (states.hasMoreElements()) {
				String s = states.nextElement();
				File f = new File(s + ".csv");
				FileWriter fw = new FileWriter(f);
				BufferedWriter bw = new BufferedWriter(fw);
				for (Subscriber sub : stateHash.get(s)) {
					bw.write(sub.toCSV() + "\n");
				}
				bw.close();
			}

		}catch (SubscriberException e) {
			// TODO Auto-generated catch block
			System.out.println(e.toString());
			
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}

	}

}
