package lecture;

import java.util.Vector;

/**
 * @author Alan Hunt
 *
 */
public class Subscriber {
	
	String firstName;
	String lastName;
	String company;
	String address;
	String city;
	String county;
	String state;
	String zip;
	String phone1;
	String phone2;
	String email;
	String web;

	public Subscriber() {

	}

	public Subscriber(Vector<String> input) throws SubscriberException {
		
		if (input.size() < 12){
			throw new SubscriberException("Not enough values");
		}
		
		if (input.size() > 12){
			throw new SubscriberException("Too many values");
		}
		
		setFirstName(input.get(0));
		setLastName(input.get(1));
		setCompany(input.get(2));
		setAddress(input.get(3));
		setCity(input.get(4));
		setCounty(input.get(5));
		setState(input.get(6));
		setZip(input.get(7));
		setPhone1(input.get(8));
		setPhone2(input.get(9));
		setEmail(input.get(10));
		setWeb(input.get(11));
	}

	public String toCSV() {
		String csv = new String();
		csv += escapeComma(firstName) + ",";
		csv += escapeComma(lastName) + ",";
		csv += escapeComma(company) + ",";
		csv += escapeComma(address) + ",";
		csv += escapeComma(city) + ",";
		csv += escapeComma(county) + ",";
		csv += escapeComma(state) + ",";
		csv += escapeComma(zip) + ",";
		csv += escapeComma(phone1) + ",";
		csv += escapeComma(phone2) + ",";
		csv += escapeComma(email) + ",";
		csv += escapeComma(web);
		return csv;
	}

	public String escapeComma(String s) {
		if (s.contains(",")) {
			return "\"" + s + "\"";
		}
		return s;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getPhone1() {
		return phone1;
	}

	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}

	public String getPhone2() {
		return phone2;
	}

	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getWeb() {
		return web;
	}

	public void setWeb(String web) {
		this.web = web;
	}

}
