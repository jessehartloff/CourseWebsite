#include "Q1.h"

double findCenter(Node* head){
    return 0.0;
}