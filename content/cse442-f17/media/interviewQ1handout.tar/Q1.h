#ifndef ASSIGNMENTS_Q1_H
#define ASSIGNMENTS_Q1_H

#include <iostream>

#include "LinkedList.h"
using namespace std;

// Find the center element of a linked list in a single pass
double findCenter(Node* head);

#endif //ASSIGNMENTS_Q1_H
